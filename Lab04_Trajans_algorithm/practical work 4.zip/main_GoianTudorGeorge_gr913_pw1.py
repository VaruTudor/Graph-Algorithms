from ui_GoianTudorGeorge_gr_913_pw4 import UI

ui = UI("example_input_activities.txt")
ui.run()